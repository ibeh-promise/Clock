let secEl = document.getElementById('sec-el')
let minEl = document.getElementById('min-el')
let hrEl = document.getElementById('hr-el')
let format = document.getElementById('format')
const clockPage = document.querySelector('.clock')
const STPage = document.querySelector('.STPage')
const timerPage = document.querySelector('.timer')
const clock_router = document.getElementById('clock_router')
const st_router = document.getElementById('st_router')
const timer_router = document.getElementById('timer_router')
const timerBtn = document.getElementById('timer-btn')
let start = document.getElementById('start');
let time = document.getElementById('time')
let pauseBtn = document.getElementById('pause');
let stop = document.getElementById('stop');
let secSt = document.getElementById('sec-st')
let hrSt = document.getElementById('hr-st')
let minSt = document.getElementById('min-st')
let secTimer = document.getElementById('sec-timer')
let hrTimer = document.getElementById('hr-timer')
let minTimer = document.getElementById('min-timer')
const hours = document.querySelector('#hours')
const options = document.querySelector('#options')
const seconds = document.querySelector('#seconds')
const inputCta = document.querySelector('.input-cta')
const timeValueCta = document.querySelector('.time-value-cta')
let resetTimer = document.getElementById('reset-timer')
let pauseTimer = document.getElementById('pause-timer');
let stopTimer = document.getElementById('stop-timer');
let sec = 0
let min = 0
let hr = 0
let hrs
let opts
let secs;
let inter;
let timerInter;


clock_router.addEventListener('click', () => {
    clockPage.style.display = 'block'
    STPage.style.display = 'none'
    timerPage.style.display = 'none'
    clock_router.style.backgroundColor = 'goldenrod'
    st_router.style.backgroundColor = 'black'
    timer_router.style.backgroundColor = 'black'
})
st_router.addEventListener('click', () => {
    clockPage.style.display = 'none'
    clock_router.style.backgroundColor = 'black'
    timer_router.style.backgroundColor = 'black'
    timerPage.style.display = 'none'
    st_router.style.backgroundColor = 'goldenrod'
    STPage.style.display = 'block'
})
timer_router.addEventListener('click', () => {
    clockPage.style.display = 'none'
    clock_router.style.backgroundColor = 'black'
    st_router.style.backgroundColor = 'black'
    timer_router.style.backgroundColor = 'goldenrod'
    STPage.style.display = 'none'
    timerPage.style.display = 'block'
})
timerBtn.addEventListener('click', () => {
    hrs = hours.value
    opts = options.value
    secs = seconds.value
    timeValueCta.style.display = 'block'
    inputCta.style.display = 'none'
    minTimer.textContent = opts
    hrTimer.textContent = hrs
    secTimer.textContent = secs
    pauseTimer.style.display = "inline-block"
    stopTimer.style.display = "inline-block"
    resetTimer.style.display = "none"
    timerInter = setInterval(() => {
        
        secTimer.textContent = secs
        if (secs < 0 ) {
            secs = 58
            opts -= 1
            minTimer.textContent = opts
            
        } else if (opts < 0) {
            opts = 59
            minTimer.textContent = opts
            hrs -= 1
            hrTimer.textContent = hrs
            
        } else if (secs == 0 && opts == 0 && hrs == 0) {
            secs = 0
            opts = 0
            hrs = 0
            minTimer.textContent = opts
            hrTimer.textContent = hrs
            secTimer.textContent = secs
            clearInterval(timerInter)
            window.alert("timer stopped")
            pauseTimer.style.display = "none"
            stopTimer.style.display = "none"
            resetTimer.style.display = "inline-block"
        }else{
            secs -= 1
        }
    },
    1000)
})

function getTime() {
    let date = new Date()
    secEl.textContent = date.getSeconds()
    minEl.textContent = date.getMinutes()
    hrEl.textContent = date.getHours()
    if (hrEl.textContent > 12) {
        format.textContent = "pm"
    } else {
        format.textContent = "am"
    }
    twelveHrFormat()
}

function twelveHrFormat() {

    if (hrEl.textContent == 13) hrEl.textContent = 1
    else if (hrEl.textContent == 14) hrEl.textContent = 2
    else if (hrEl.textContent == 15) hrEl.textContent = 3
    else if (hrEl.textContent == 16) hrEl.textContent = 4
    else if (hrEl.textContent == 17) hrEl.textContent = 5
    else if (hrEl.textContent == 18) hrEl.textContent = 6
    else if (hrEl.textContent == 19) hrEl.textContent = 7
    else if (hrEl.textContent == 20) hrEl.textContent = 8
    else if (hrEl.textContent == 21) hrEl.textContent = 9
    else if (hrEl.textContent == 22) hrEl.textContent = 10
    else if (hrEl.textContent == 23) hrEl.textContent = 11
    else if (hrEl.textContent == 24) hrEl.textContent = 12
}

setInterval(() => getTime(), 10)

start.addEventListener('click', () => {
    inter = setInterval(() => {
        pauseBtn.style.display = "inline-block"
        start.style.display = "none"
        sec += 1
        secSt.textContent = sec
        if (sec == 60) {
            min += 1
            sec = 0
            minSt.textContent = min
        } else if (min == 60) {
            hr += 1
            min = 0
            hrSt.textContent = hr
        }
    },
        16)
})

stop.addEventListener('click', () => {
    min = 0
    sec = 0
    hr = 0
    clearInterval(inter)
    secSt.textContent = sec
    minSt.textContent = min
    hrSt.textContent = hr
    pauseBtn.style.display = "none"
    start.style.display = "inline-block"
})

pauseBtn.addEventListener('click', () => {
    clearInterval(inter)
    secSt.textContent = sec
    start.style.display = "inline-block"
    pauseBtn.style.display = "none"
})

resetTimer.addEventListener('click', () => {
    timeValueCta.style.display = 'none'
    inputCta.style.display = 'grid'
    inputCta.style.marginTop = "0%"
})

stopTimer.addEventListener('click', () => {
    opts = 0
    secs = 0
    hrs = 0
    clearInterval(timerInter)
    secTimer.textContent = sec
    minTimer.textContent = min
    hrTimer.textContent = hr
    pauseTimer.style.display = "none"
    stopTimer.style.display = "none"
    resetTimer.style.display = "inline-block"
})

pauseTimer.addEventListener('click', () => {
    clearInterval(timerInter)
    secTimer.textContent = secs
    resetTimer.style.display = "inline-block"
    pauseTimer.style.display = "none"
})